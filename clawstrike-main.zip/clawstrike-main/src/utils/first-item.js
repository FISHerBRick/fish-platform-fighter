firstItem = (iterable) => {
    for (const item of iterable) {
        return item;
    }
}
