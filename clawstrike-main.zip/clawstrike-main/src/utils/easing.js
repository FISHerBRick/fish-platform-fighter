easeInQuad = (x) => x * x;
easeOutSine = (x) => sin((x * PI) / 2);
linear = (x) => x;
